## Overview
This repository is to be used for Stony Brook University's CSE 316, Fall 2025 Semester, Homework 1. This assignment is part one in a series of assignments that will culminate in students designing and implementing a program for creating and playing musical playlists. This application will be called <strong><em>The Playlister</em></strong>.

All assignment instructions are provided <a href='https://www.cs.stonybrook.edu/~cse316/hw1.html'>here</a>.